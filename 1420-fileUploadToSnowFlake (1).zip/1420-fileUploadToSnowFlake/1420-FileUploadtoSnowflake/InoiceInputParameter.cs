﻿

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace _1420_FileUploadtoSnowflake.Controllers
{
    public class InoiceInputParameter
    {   public Stream fileContent { get; set; }
        public string FileName { get; set; }
        public IFormFile files { get; set; }
        public string? InvoiceId { get; set; }
        public string? PurchaseOrder { get; set; }
        public string? InvoiceTotal { get; set; }
        public string? Item { get; set; }
        public string? SubTotal { get; set; }
        public string? TotalTax { get; set; }
        public string? InvoiceDate { get; set; }
        public string? DueDate { get; set; }
        public string? ServiceAddress { get; set; }
        public string? ServiceStartDate { get; set; }
        public string? CustomerId { get; set; }
        public string? CustomerName { get; set; }
        public string? CustomerAddress { get; set; }
        public string? RemittanceAddressRecipient { get; set; }
        public string? RemittanceAddress { get; set; }
        public string? BillingAddress { get; set; }
        public string? BillingAddressRecipient { get; set; }
        public string? ShippingAddress { get; set; }
        public string? ShippingAddressRecipient { get; set; }
        public string? VendorName { get; set; }
        public string? VendorAddress { get; set; }
        public string? VendorAddressRecipient { get; set; }
        public string? AmountDue { get; set; }

        


    }
}

