﻿namespace DataInvoiceManager.API.Models
{
    public class Tenant : Base
    {
        public string TenantName { get; set; }
        public Status Status { get; set; }
    }
}
