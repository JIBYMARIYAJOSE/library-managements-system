using Snowflake.Client;

namespace _1334_fetchFromSnowflake.Controllers
    
    public static class Common
    {
        public static SnowflakeClient getClient()
        {
            var snowflakeClient = new SnowflakeClient("skywalkelectric", "Prabhakar123", "ek22605", "east-us-2.azure");
            return snowflakeClient;
        }
    }
}
