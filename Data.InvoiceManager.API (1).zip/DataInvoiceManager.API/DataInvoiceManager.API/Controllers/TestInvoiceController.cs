﻿using Azure.AI.FormRecognizer.Models;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Headers;
using System.Text.Json;

namespace DataInvoiceManager.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TestInvoiceController : ControllerBase
    {   [HttpPost("uploadFile"), DisableRequestSizeLimit]
        public async Task<Invoice> uploadFile(IFormCollection data)
        {
            Invoice invoiceData = new Invoice();
            try
            {  var file = Request.Form.Files[0];
               var payload = JsonSerializer.Deserialize<Invoice>(data["requestData"]);
                var supplierId = payload.vendorId;
                var folderName = Path.Combine("Resources", "Uploads");
                var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);
                if (file.Length > 0)
                {
                    var fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                    var fullPath = Path.Combine(pathToSave, fileName);
                    var dbPath = Path.Combine(folderName, fileName);
                    using (var str = new FileStream(fullPath, FileMode.Create))
                    { file.CopyTo(str);
                    }
                }
                 return invoiceData;
            }
            catch (Exception ex)
            {
                return invoiceData;
                
            }
        }
        
       
    }
}
