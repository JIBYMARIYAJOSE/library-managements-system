using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Azure;
using Azure.AI.FormRecognizer;
using System.Collections.Generic;
using Azure.AI.FormRecognizer.Models;
using System.Web.Http;
using System.Net;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace JSONConverter
{
    public class convertToPdf
    {

        [FunctionName("convertToPdf")]
        public async Task<dynamic> Run(
              [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            var formdata = await req.ReadFormAsync();
            var file = req.Form.Files[0];
            Invoice invoiceData = await parsePdf(file);
            string jsonString = System.Text.Json.JsonSerializer.Serialize(invoiceData);
            dynamic json = JsonConvert.DeserializeObject(jsonString);
            return json;

        }

        public async Task<Invoice> parsePdf(IFormFile file)
        {
            var invoiceObject = new Invoice();
            try
            {
                JSONConverter.Config config = new JSONConverter.Config();

                string endPoint = config.getValue("endPoint");
                string apiKey = config.getValue("apiKey");
                var credential = new AzureKeyCredential(apiKey);
                var client = new FormRecognizerClient(new Uri(endPoint), credential);
                Stream stream = file.OpenReadStream();
                var options = new RecognizeInvoicesOptions() { Locale = "en-US" };
                RecognizeInvoicesOperation operation = await client.StartRecognizeInvoicesAsync(stream, options);
                Response<RecognizedFormCollection> operationResponse = await operation.WaitForCompletionAsync();
                RecognizedFormCollection invoices = operationResponse.Value;
                RecognizedForm invoice = invoices.Single();

                invoiceObject.files = file;
                invoiceObject.InvoiceId = (invoice.Fields.ContainsKey("InvoiceId")) ? invoice.Fields["InvoiceId"].ValueData.Text : null;
                invoiceObject.PurchaseOrder = (invoice.Fields.ContainsKey("PurchaseOrder")) ? invoice.Fields["PurchaseOrder"].ValueData.Text : null;
                invoiceObject.InvoiceTotal = (invoice.Fields.ContainsKey("InvoiceTotal")) ? (invoice.Fields["InvoiceTotal"].ValueData.Text) : null;
                invoiceObject.SubTotal = (invoice.Fields.ContainsKey("SubTotal")) ? (invoice.Fields["SubTotal"].ValueData.Text) : null;
                invoiceObject.TotalTax = (invoice.Fields.ContainsKey("TotalTax")) ? (invoice.Fields["TotalTax"].ValueData.Text) : null;
                invoiceObject.InvoiceDate = (invoice.Fields.ContainsKey("InvoiceDate")) ? invoice.Fields["InvoiceDate"].ValueData.Text : null;
                invoiceObject.DueDate = (invoice.Fields.ContainsKey("DueDate")) ? invoice.Fields["DueDate"].ValueData.Text : null;
                invoiceObject.CustomerId = (invoice.Fields.ContainsKey("CustomerId")) ? invoice.Fields["CustomerId"].ValueData.Text : null;
                invoiceObject.CustomerName = (invoice.Fields.ContainsKey("CustomerName")) ? invoice.Fields["CustomerName"].ValueData.Text : null;
                invoiceObject.BillingAddress = (invoice.Fields.ContainsKey("BillingAddress")) ? invoice.Fields["BillingAddress"].ValueData.Text : null;
                invoiceObject.BillingAddressRecipient = (invoice.Fields.ContainsKey("BillingAddressRecipient")) ? invoice.Fields["BillingAddressRecipient"].ValueData.Text : null;
                invoiceObject.ShippingAddress = (invoice.Fields.ContainsKey("ShippingAddress")) ? invoice.Fields["ShippingAddress"].ValueData.Text : null;
                invoiceObject.ShippingAddressRecipient = (invoice.Fields.ContainsKey("ShippingAddressRecipient")) ? invoice.Fields["ShippingAddressRecipient"].ValueData.Text : null;
                invoiceObject.VendorName = (invoice.Fields.ContainsKey("VendorName")) ? invoice.Fields["VendorName"].ValueData.Text : null;
                invoiceObject.VendorAddress = (invoice.Fields.ContainsKey("VendorAddress")) ? invoice.Fields["VendorAddress"].ValueData.Text : null;
                invoiceObject.VendorAddressRecipient = (invoice.Fields.ContainsKey("VendorAddressRecipient")) ? invoice.Fields["VendorAddressRecipient"].ValueData.Text : null;
                invoiceObject.CustomerAddress = (invoice.Fields.ContainsKey("CustomerAddress")) ? invoice.Fields["CustomerAddress"].ValueData.Text : null;
                invoiceObject.RemittanceAddress = (invoice.Fields.ContainsKey("RemittanceAddress")) ? invoice.Fields["RemittanceAddress"].ValueData.Text : null;
                invoiceObject.RemittanceAddressRecipient = (invoice.Fields.ContainsKey("RemittanceAddressRecipient")) ? invoice.Fields["RemittanceAddressRecipient"].ValueData.Text : null;
                invoiceObject.ServiceStartDate = (invoice.Fields.ContainsKey("ServiceStartDate")) ? invoice.Fields["ServiceStartDate"].ValueData.Text : null;
                invoiceObject.ServiceAddress = (invoice.Fields.ContainsKey("ServiceAddress")) ? invoice.Fields["ServiceAddress"].ValueData.Text : null;
                invoiceObject.AmountDue = (invoice.Fields.ContainsKey("AmountDue")) ? invoice.Fields["AmountDue"].ValueData.Text : null;


                IList<Item> nItemsList = new List<Item>();
                OutputItem outObj = new OutputItem();
                outObj.Items = new List<Item>();

                outObj.itemsList = nItemsList;
                invoiceObject.ItemsList = nItemsList;

                foreach (var Item in invoices)
                {

                    foreach (FormField field in invoice.Fields.Values)
                    {


                        if (field.Name == "Items")
                        {

                            IEnumerable<Item> items = new List<Item>();

                            foreach (var lineField in field.Value.AsList())
                            {

                                Item obj = new Item();
                                foreach (var (lineFieldName, lineFieldValue) in lineField.Value.AsDictionary())
                                {

                                    if (lineFieldName == "Amount")
                                    {
                                        obj.Amount = lineFieldValue.ValueData?.Text;
                                    }
                                    if (lineFieldName == "Description")
                                    {
                                        obj.Description = lineFieldValue.ValueData?.Text;
                                    }
                                    if (lineFieldName == "Quantity")
                                    {
                                        obj.Quantity = lineFieldValue.ValueData?.Text;
                                    }
                                    if (lineFieldName == "UnitPrice")
                                    {
                                        obj.UnitPrice = lineFieldValue.ValueData?.Text;
                                    }
                                    if (lineFieldName == "Unit")
                                    {
                                        obj.Unit = lineFieldValue.ValueData?.Text;
                                    }
                                    if (lineFieldName == "ProductCode")
                                    {
                                        obj.ProductCode = lineFieldValue.ValueData?.Text;
                                    }

                                }
                                if (obj != null)
                                {
                                    nItemsList.Add(obj);

                                }

                            }


                        }

    }

                }


            }


            catch (System.Exception ex)
            {
                throw new HttpResponseException(HttpStatusCode.NotFound);
            }
            return invoiceObject;

        }
    }


    [Serializable]
    public class Item
    {
        //public string Name { get; set; }
        //public string Version { get; set; }

        [Column(TypeName = "VARCHAR")]
        [StringLength(50)]
        [Display(Name = "Amount")]
        public string Amount { get; set; }

[Column(TypeName = "VARCHAR")]
[StringLength(50)]
[Display(Name = "Description")]
public string Description { get; set; }

[Column(TypeName = "VARCHAR")]
[StringLength(50)]
[Display(Name = "Quantity")]
public string Quantity { get; set; }

[Column(TypeName = "string")]
[StringLength(50)]
[Display(Name = "UnitPrice")]
public string UnitPrice { get; set; }

[Column(TypeName = "string")]
[StringLength(50)]
[Display(Name = "ProductCode")]
public string ProductCode { get; set; }

[Column(TypeName = "string")]
[StringLength(50)]
[Display(Name = "Unit")]
public string Unit { get; set; }

[Column(TypeName = "string")]
[StringLength(50)]
[Display(Name = "Date")]
public string Date { get; set; }

        [Column(TypeName = "string")]
        [StringLength(50)]
        [Display(Name = "Tax")]
        public string Tax { get; set; }
    }
    [Serializable]
    public class OutputItem
    {
        // public List<Item> Items { get; set; }
        public IEnumerable<Item> Items { get; set; }
        public IList<Item> itemsList { get; set; }
    }

    [Serializable]
    public class ItemsList
    {
        // public List<Item> Items { get; set; }
        public IList<Item> myItemsList { get; set; }
    }

}

