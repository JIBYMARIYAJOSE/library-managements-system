﻿using DataInvoiceManager.API.Core.Models;

namespace DataInvoiceManager.API.Core.Interfaces
{
    public interface ISupplierRepository
    {
        Task<IEnumerable<Supplier>> getList(string Limit);
    }
}
