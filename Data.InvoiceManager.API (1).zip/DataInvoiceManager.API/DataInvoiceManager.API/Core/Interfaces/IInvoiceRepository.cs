﻿using DataInvoiceManager.API.Core.Models;

namespace DataInvoiceManager.API.Core.Interfaces
{
    public interface IInvoiceRepository
    {
          Task<IEnumerable<Invoice>> getList(string supplierId, string limit);
        
    }
}
