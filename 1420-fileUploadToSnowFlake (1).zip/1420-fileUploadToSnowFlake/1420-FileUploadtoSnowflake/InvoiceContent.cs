using Snowflake.Client;

namespace _1420_FileUploadtoSnowflake
{
    public class InvoiceContent
    {


        public async Task<long> StoreAsync()
        {
            var snowflakeClient = new SnowflakeClient("Dora", "Prabhakar123", "tt45109", "southeast-asia.azure");

            var obj = new InvoiceInputParameter();
            var obj2 = new InvoiceInputParameter();



            try
            {
                string useRoleResult = await snowflakeClient.ExecuteScalarAsync("USE ROLE ACCOUNTADMIN;");

                var vals = "values (" + obj.FileName + ",'" + obj.files + "')";

                vals += "(" + obj2.FileName + ",'" + obj2.files + "')";



                var sqlstmt = "INSERT INTO KLINEELECTRIC.PUBLIC.INVOICES (fileName,fileContent) " + vals;

                var results = await snowflakeClient.ExecuteAsync(sqlstmt);

                return results;

            }
            catch (Exception ex)
            {
                throw new Exception("some Isue: " + ex.Message);
            }

        }
    }
}
