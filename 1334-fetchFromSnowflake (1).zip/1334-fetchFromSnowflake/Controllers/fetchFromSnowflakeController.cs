﻿using Microsoft.AspNetCore.Mvc;
using Snowflake.Client;
using Snowflake.Data.Client;

namespace _1334_fetchFromSnowflake.Controllers
{
    public class fetchFromSnowflakeController : Controller
    {
        [HttpGet("GetInvoice")]
                public async Task<IEnumerable<Invoice>> GetInvoice()
                {
                  
                    var snowflakeClient = Common.getClient();
                     //var snowflakeClient = new SnowflakeClient("skywalkelectric", "Prabhakar123", "ek22605", "east-us-2.azure");
                    var invoices = await snowflakeClient.QueryAsync<Invoice>("SELECT * FROM KLINEELECTRIC.PUBLIC.INVOICES limit 10");
                    // var invoiceItems = await snowflakeClient.QueryAsync<InvoiceItems>("SELECT * FROM KLINEELECTRIC.PUBLIC.INVOICEITEMS limit 10");
                    string useRoleResult = await snowflakeClient.ExecuteScalarAsync("USE ROLE ACCOUNTADMIN;");


                    return invoices;
                }
             [HttpGet("GetInvoiceItem")]
        public async Task<IEnumerable<InvoiceItems>> GetInvoiceItem()
        {


            var snowflakeClient = Common.getClient();
            //var snowflakeClient = new SnowflakeClient("skywalkelectric", "Prabhakar123", "ek22605", "east-us-2.azure");
            //var invoices = await snowflakeClient.QueryAsync<Invoice>("SELECT * FROM KLINEELECTRIC.PUBLIC.INVOICES limit 10");
            var invoiceItems = await snowflakeClient.QueryAsync<InvoiceItems>("SELECT * FROM KLINEELECTRIC.PUBLIC.INVOICEITEMS limit 10");
            string useRoleResult = await snowflakeClient.ExecuteScalarAsync("USE ROLE ACCOUNTADMIN;");


            return invoiceItems;
        }
        [HttpGet("Getfile")]
        public async Task<IEnumerable<FileDownload>> Getfile()
        {


           Invoice invoice = new Invoice();
            var file = Request.Form.Files[0];
            var fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
            var requestContent = new MultipartFormDataContent();
            requestContent.Add(new StringContent(fileName), "fileName");
            requestContent.Add(new StreamContent(file.OpenReadStream()), "files");
            var client = await Common.getClient(_config);
            //string url = Common.getConfigValue(_config, "AzureBaseURL");
            // url = url + "convertToPdf";
            string url = " http://localhost:7071/api/convertToPdf";
            var response = await client.PostAsync(url, requestContent);
            Stream streamToReadFrom = await response.Content.ReadAsStreamAsync();
            invoice.fileContent = streamToReadFrom;
              var snowflakeClient = Common.getClient();
            //var snowflakeClient = new SnowflakeClient("skywalkelectric", "Prabhakar123", "ek22605", "east-us-2.azure");
            var Files = await snowflakeClient.QueryAsync<FileDownload>("SELECT * FROM KLINEELECTRIC.PUBLIC.INVOICES limit 10");
           // var invoiceItems = await snowflakeClient.QueryAsync<InvoiceItems>("SELECT * FROM KLINEELECTRIC.PUBLIC.INVOICEITEMS limit 10");
            string useRoleResult = await snowflakeClient.ExecuteScalarAsync("USE ROLE ACCOUNTADMIN;");

            InsertToSnowflake();
            return Files;

            return file;
        }
        [HttpGet("InsertToSnowflake")]
       


            public async Task<long> InsertToSnowflake()
            {
                var repo = new InvoiceContent();


                return await repo.StoreAsync();

            }



    }
}
