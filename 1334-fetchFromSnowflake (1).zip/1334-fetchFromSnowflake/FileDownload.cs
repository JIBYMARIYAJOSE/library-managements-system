namespace _1334_fetchFromSnowflake.Controllers
{
    public class FileDownload
    {
        public string FileName { get; set; }
    }
}
