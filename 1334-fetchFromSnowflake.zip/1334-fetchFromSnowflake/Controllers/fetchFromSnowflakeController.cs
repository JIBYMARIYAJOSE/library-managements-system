﻿using Microsoft.AspNetCore.Mvc;
using Snowflake.Client;
using Snowflake.Data.Client;

namespace _1334_fetchFromSnowflake.Controllers
{
    public class fetchFromSnowflakeController : Controller
    {
        [HttpGet("GetInvoice")]
                public async Task<IEnumerable<Invoice>> GetInvoice()
                {
                  
                    var snowflakeClient = Common.getClient();
                     //var snowflakeClient = new SnowflakeClient("skywalkelectric", "Prabhakar123", "ek22605", "east-us-2.azure");
                    var invoices = await snowflakeClient.QueryAsync<Invoice>("SELECT * FROM KLINEELECTRIC.PUBLIC.INVOICES limit 10");
                    // var invoiceItems = await snowflakeClient.QueryAsync<InvoiceItems>("SELECT * FROM KLINEELECTRIC.PUBLIC.INVOICEITEMS limit 10");
                    string useRoleResult = await snowflakeClient.ExecuteScalarAsync("USE ROLE ACCOUNTADMIN;");


                    return invoices;
                }
             [HttpGet("GetInvoiceItem")]
        public async Task<IEnumerable<InvoiceItems>> GetInvoiceItem()
        {


            var snowflakeClient = Common.getClient();
            //var snowflakeClient = new SnowflakeClient("skywalkelectric", "Prabhakar123", "ek22605", "east-us-2.azure");
            //var invoices = await snowflakeClient.QueryAsync<Invoice>("SELECT * FROM KLINEELECTRIC.PUBLIC.INVOICES limit 10");
            var invoiceItems = await snowflakeClient.QueryAsync<InvoiceItems>("SELECT * FROM KLINEELECTRIC.PUBLIC.INVOICEITEMS limit 10");
            string useRoleResult = await snowflakeClient.ExecuteScalarAsync("USE ROLE ACCOUNTADMIN;");


            return invoiceItems;
        }
        [HttpGet("Getfile")]
        public async Task<IEnumerable<FileDownload>> Getfile()
        {


            var snowflakeClient = Common.getClient();
            //var snowflakeClient = new SnowflakeClient("skywalkelectric", "Prabhakar123", "ek22605", "east-us-2.azure");
            var file = await snowflakeClient.QueryAsync<FileDownload>("SELECT * FROM KLINEELECTRIC.PUBLIC.INVOICES limit 10");
           // var invoiceItems = await snowflakeClient.QueryAsync<InvoiceItems>("SELECT * FROM KLINEELECTRIC.PUBLIC.INVOICEITEMS limit 10");
            string useRoleResult = await snowflakeClient.ExecuteScalarAsync("USE ROLE ACCOUNTADMIN;");


            return file;
        }


    }
}
