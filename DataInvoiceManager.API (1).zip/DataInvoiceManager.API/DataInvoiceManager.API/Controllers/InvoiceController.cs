﻿using Microsoft.AspNetCore.Mvc;
using DataInvoiceManager.API.Core.Models;
using DataInvoiceManager.API.Core.Helpers;
using DataInvoiceManager.API.Core.Interfaces;

namespace DataInvoiceManager.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    
    public class InvoiceController : Controller
    {
       

        private readonly IWebHostEnvironment _env;
        private readonly IConfiguration _config;
        private readonly IInvoiceRepository _invoiceRepo;


        public InvoiceController(IWebHostEnvironment env, IConfiguration config, IInvoiceRepository invoiceRepo)
        {
            _env = env;
            _config = config;
            _invoiceRepo = invoiceRepo;
        }

        [HttpGet("getList/{supplierId}")]
        public async Task<IEnumerable<Invoice>> getList(int? supplierId, [FromQuery] int? limit)
        {
            return await _invoiceRepo.getList(supplierId, Common.getLimit(limit, _config));
        }

        [HttpGet("getInvoiceFile")]
        public async Task<IActionResult> getInvoiceFile([FromQuery] string fileName, string destPrefix, string stageName, string compression)
        {
            var client = await Common.getClient(_config);
            string url = Common.getConfigValue(_config, "AzureBaseURL");
            url = url + "FileDownload";
            client.BaseAddress = new Uri(url);
            var requestContent = new MultipartFormDataContent();

            requestContent.Add(new StringContent(destPrefix), "destPrefix");
            requestContent.Add(new StringContent(fileName), "fileName");
            requestContent.Add(new StringContent(compression), "compression");
            requestContent.Add(new StringContent(stageName), "stageName");

            try
            {
                var response = await client.PostAsync(url, requestContent);

                if (response.IsSuccessStatusCode)
                {
                    return Ok(await response.Content.ReadAsStreamAsync());
                }

                return NotFound(response.StatusCode.ToString());
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
            
        }
    }



}
