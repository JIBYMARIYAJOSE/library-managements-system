using Snowflake.Client;

namespace _1334_fetchFromSnowflake.Controllers
    
    public static class Common
    {
        public static SnowflakeClient getClient()
        {
            var snowflakeClient = new SnowflakeClient("skywalkelectric", "Prabhakar123", "ek22605", "east-us-2.azure");
            return snowflakeClient;
        }
         public static String getConfigValue(IConfiguration _config, String key)
        {
            return _config[key];
        }
        public static async Task<AuthenticationResult> getBearerToken(IConfiguration _config, ClientCredential clientSecretCredential)
        {
            var authContext = new AuthenticationContext(Common.getConfigValue(_config, "AccessLogin") + Common.getConfigValue(_config, "TenantId"), false);
            var token = await authContext.AcquireTokenAsync(Common.getConfigValue(_config, "ObjectId"), clientSecretCredential);
            return token;
        }

        public static string getLimit(string limit, IConfiguration _config)
        {
            if (limit == null)
            {
                limit = Common.getConfigValue(_config, "DefaultPageSize");
            }

            return limit;
        }

        public static async Task<HttpClient> getClient(IConfiguration _config)
        {
            string clientId = Common.getConfigValue(_config, "ClientId");
            string clientSecret = Common.getConfigValue(_config, "ClientSecret");
            string tenantId = Common.getConfigValue(_config, "TenantId");

            var credentials = new ClientCredential(clientId, clientSecret);
            var token = await Common.getBearerToken(_config, credentials);

            HttpClient client = new HttpClient();

            client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token.AccessToken);

            return client;
        }
    }
}
