﻿using Microsoft.AspNetCore.Mvc;
using Snowflake.Client;
using Snowflake.Data.Client;
using System.Data;
using System.Net.Http.Headers;
using Newtonsoft.Json;

namespace _1420_FileUploadtoSnowflake.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UploadFileController : ControllerBase

    {
       
        
      

        [HttpGet("snowflake")]
                public async Task<IEnumerable<InoiceInputParameter>> GetSnowflake()
                {
                  
                    InoiceInputParameter invoice = new InoiceInputParameter();
                     var file = Request.Form.Files[0];
                     var fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                     var requestContent = new MultipartFormDataContent();
                     requestContent.Add(new StringContent(fileName), "fileName");
                     requestContent.Add(new StreamContent(file.OpenReadStream()), "files");
                     var client = await Common.getClient(_config);
                     string url = Common.getConfigValue(_config, "AzureBaseURL");
                     url = url + "convertToPdf";
                     var response = await client.PostAsync(url,requestContent);
                     Stream streamToReadFrom = await response.Content.ReadAsStreamAsync();
                     invoice.fileContent = streamToReadFrom;
                    var snowflakeClient = new SnowflakeClient("skywalkelectric", "Prabhakar123", "ek22605", "east-us-2.azure");
                    var invoices = await snowflakeClient.QueryAsync<InvoiceInputParameter>("SELECT * FROM KLINEELECTRIC.PUBLIC.INVOICES limit 10");
                    string useRoleResult = await snowflakeClient.ExecuteScalarAsync("USE ROLE ACCOUNTADMIN;");
                    //long  affectedRows = await snowflakeClient.ExecuteAsync("INSERT INTO INVOICEDATA FILE VALUES (?);", invoice.fileContent);
                     InsertToSnowflake();
                 return invoices;
                }
         [HttpGet("snowflakeInsert")]
        public async Task<long> InsertToSnowflake()
        {
            var repo  = new InvoiceContent();
            

             return await repo.StoreAsync();
           
        }

}

    } 

    

