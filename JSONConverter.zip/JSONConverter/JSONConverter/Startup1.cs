﻿using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Azure.WebJobs.Host.Bindings;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Microsoft.Owin;
using Owin;
using System;
using System.IO;
using System.Threading.Tasks;

[assembly: OwinStartup(typeof(JSONConverter.Startup1))]

namespace JSONConverter
{
    public class Startup1
    {
        public  void ConfigureAppConfiguration(IFunctionsConfigurationBuilder builder)
        {
            builder.ConfigurationBuilder.AddAzureAppConfiguration(options =>
            {
                options.Connect(Environment.GetEnvironmentVariable("ApplicationSetting"))
                       // Load all keys that start with `TestApp:`
                       .Select("*")
                       // Configure to reload configuration if the registered sentinel key is modified
                       .ConfigureRefresh(refreshOptions =>
                          refreshOptions.Register("TestApp:Settings:Sentinel", refreshAll: true));
          });
        }
      ///  public  void ConfigureAppConfiguration(IFunctionsConfigurationBuilder builder)
      ///  {
      ///      var executioncontextoptions = builder.Services.BuildServiceProvider()
   ///  .GetService<IOptions<ExecutionContextOptions>>().Value;
      ///      var currentDirectory = executioncontextoptions.AppDirectory;

        ///    var config = new ConfigurationBuilder()
         ///      .SetBasePath(currentDirectory)
          ////     .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
          ///     .AddEnvironmentVariables()
          ///     .Build();
    ///    }

    ///    public void Configure(IFunctionsHostBuilder builder)
    ///    {
    ///    }
    }
}
