﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JSONConverter
{
  public  class ConvertToPdfWorking
    {
        using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Azure.AI.FormRecognizer;
using Azure.AI.FormRecognizer.Models;
using Azure;
using System.Linq;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Hosting;
using System.Configuration;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Net.Http;
using Newtonsoft.Json.Linq;
using System.Web.Http;
using ServiceStack;
using System.Net;
using java.lang;
using System.Collections;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace JSONConverter
    {
        public class convertToPdf
        {

            private readonly IConfiguration _config;


            public convertToPdf(IConfiguration config)
            {

                _config = config;

            }
            // private static readonly IWebHost _env;

            [FunctionName("convertToPdf")]
            public async Task<dynamic> Run(
                  [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] HttpRequest req,
                ILogger log)
            {
                var formdata = await req.ReadFormAsync();
                var file = req.Form.Files[0];
                Invoice invoiceData = await parsePdf(file);
                string jsonString = System.Text.Json.JsonSerializer.Serialize(invoiceData);
                dynamic json = JsonConvert.DeserializeObject(jsonString);
                return json;

            }

            public async Task<Invoice> parsePdf(IFormFile file)
            {
                var invoiceObject = new Invoice();
                try
                {
                    JSONConverter.Config config = new JSONConverter.Config();

                    string endPoint = config.getValue("endPoint");
                    string apiKey = config.getValue("apiKey");
                    var credential = new AzureKeyCredential(apiKey);
                    var client = new FormRecognizerClient(new Uri(endPoint), credential);
                    Stream stream = file.OpenReadStream();
                    var options = new RecognizeInvoicesOptions() { Locale = "en-US" };
                    RecognizeInvoicesOperation operation = await client.StartRecognizeInvoicesAsync(stream, options);
                    Response<RecognizedFormCollection> operationResponse = await operation.WaitForCompletionAsync();
                    RecognizedFormCollection invoices = operationResponse.Value;
                    RecognizedForm invoice = invoices.Single();
                    invoiceObject.files = file;
                    invoiceObject.InvoiceId = (invoice.Fields.ContainsKey("InvoiceId")) ? invoice.Fields["InvoiceId"].ValueData.Text : null;
                    invoiceObject.PurchaseOrder = (invoice.Fields.ContainsKey("PurchaseOrder")) ? invoice.Fields["PurchaseOrder"].ValueData.Text : null;
                    invoiceObject.InvoiceTotal = (invoice.Fields.ContainsKey("InvoiceTotal")) ? (invoice.Fields["InvoiceTotal"].ValueData.Text) : null;
                    invoiceObject.SubTotal = (invoice.Fields.ContainsKey("SubTotal")) ? (invoice.Fields["SubTotal"].ValueData.Text) : null;
                    invoiceObject.TotalTax = (invoice.Fields.ContainsKey("TotalTax")) ? (invoice.Fields["TotalTax"].ValueData.Text) : null;
                    invoiceObject.InvoiceDate = (invoice.Fields.ContainsKey("InvoiceDate")) ? invoice.Fields["InvoiceDate"].ValueData.Text : null;
                    invoiceObject.DueDate = (invoice.Fields.ContainsKey("DueDate")) ? invoice.Fields["DueDate"].ValueData.Text : null;
                    invoiceObject.CustomerId = (invoice.Fields.ContainsKey("CustomerId")) ? invoice.Fields["CustomerId"].ValueData.Text : null;
                    invoiceObject.CustomerName = (invoice.Fields.ContainsKey("CustomerName")) ? invoice.Fields["CustomerName"].ValueData.Text : null;
                    invoiceObject.BillingAddress = (invoice.Fields.ContainsKey("BillingAddress")) ? invoice.Fields["BillingAddress"].ValueData.Text : null;
                    invoiceObject.BillingAddressRecipient = (invoice.Fields.ContainsKey("BillingAddressRecipient")) ? invoice.Fields["BillingAddressRecipient"].ValueData.Text : null;
                    invoiceObject.ShippingAddress = (invoice.Fields.ContainsKey("ShippingAddress")) ? invoice.Fields["ShippingAddress"].ValueData.Text : null;
                    invoiceObject.ShippingAddressRecipient = (invoice.Fields.ContainsKey("ShippingAddressRecipient")) ? invoice.Fields["ShippingAddressRecipient"].ValueData.Text : null;
                    invoiceObject.VendorName = (invoice.Fields.ContainsKey("VendorName")) ? invoice.Fields["VendorName"].ValueData.Text : null;
                    invoiceObject.VendorAddress = (invoice.Fields.ContainsKey("VendorAddress")) ? invoice.Fields["VendorAddress"].ValueData.Text : null;
                    invoiceObject.VendorAddressRecipient = (invoice.Fields.ContainsKey("VendorAddressRecipient")) ? invoice.Fields["VendorAddressRecipient"].ValueData.Text : null;
                    invoiceObject.CustomerAddress = (invoice.Fields.ContainsKey("CustomerAddress")) ? invoice.Fields["CustomerAddress"].ValueData.Text : null;
                    invoiceObject.RemittanceAddress = (invoice.Fields.ContainsKey("RemittanceAddress")) ? invoice.Fields["RemittanceAddress"].ValueData.Text : null;
                    invoiceObject.RemittanceAddressRecipient = (invoice.Fields.ContainsKey("RemittanceAddressRecipient")) ? invoice.Fields["RemittanceAddressRecipient"].ValueData.Text : null;
                    invoiceObject.ServiceStartDate = (invoice.Fields.ContainsKey("ServiceStartDate")) ? invoice.Fields["ServiceStartDate"].ValueData.Text : null;
                    invoiceObject.ServiceAddress = (invoice.Fields.ContainsKey("ServiceAddress")) ? invoice.Fields["ServiceAddress"].ValueData.Text : null;
                    invoiceObject.AmountDue = (invoice.Fields.ContainsKey("AmountDue")) ? invoice.Fields["AmountDue"].ValueData.Text : null;
                    //invoiceObject.Items = (invoice.Fields.ContainsKey("Items")) ? invoice.Fields["Items"].ValueData.Text : null;
                    //invoiceObject.Items = (invoice.Fields.ContainsKey("Items")) ? invoice.Fields["Items"].ValueData.Text : null;
                    //invoiceObject.Description = (invoice.Fields.ContainsKey("Description")) ? invoice.Fields["Description"].ValueData.Text : null;
                    /*foreach (var item in invoiceObject.Items)
                    {
                       // invoiceObject.Amount = Int.parseInt((invoice.Fields.ContainsKey("Amount")) ? invoice.Fields["Amount"].ValueData.Text:null);
                        invoiceObject.Description = (invoice.Fields.ContainsKey("Description")) ? invoice.Fields["Description"].ValueData.Text : null;
                        invoiceObject.Quantity = (invoice.Fields.ContainsKey("Quantity")) ? invoice.Fields["Quantity"].ValueData.Text : null;
                        //invoiceObject.UnitPrice = (invoice.Fields.ContainsKey("UnitPrice")) ? invoice.Fields["UnitPrice"].ValueData.Text : null;
                        invoiceObject.ProductCode = (invoice.Fields.ContainsKey("ProductCode")) ? invoice.Fields["ProductCode"].ValueData.Text : null;
                    }*/
                    /*Item[] itemsList = new Item[10];
                    foreach (var Item in operation.Value)
                    {

                        foreach (FormField field in invoice.Fields.Values)
                        {
                            Item obj = new Item();
                            OutputItem outObj = new OutputItem();
                            Console.WriteLine($"Field {field.Name}: ");
                            Console.WriteLine($"    Value: {field.ValueData?.Text}");

                            if (field.Name == "Items")
                            {
                                //Item obj = new Item();
                                // OutputItem outObj = new OutputItem();
                                var count = 0;
                                // IEnumerable<Item> items = new[] { obj };
                                IEnumerable<Item> items = new List<Item>();
                                // items = items.Concat(new[] { obj });
                                //outObj.Items = new[] { obj };
                                outObj.Items = new List<Item>();

                                foreach (var lineField in field.Value.AsList())
                                {
                                    var inc = 0;
                                    count++;
                                    Console.WriteLine($"     LineItem {count}: ");
                                    //outObj.Items = new[] { obj };
                                    //   IEnumerable<Item> items = new[] { obj };
                                    //items = items.Concat(new[] { obj });
                                    foreach (var (lineFieldName, lineFieldValue) in lineField.Value.AsDictionary())
                                    {
                                        FormField feild;


                                        Console.WriteLine($"        LineField: {lineFieldName}");
                                        Console.WriteLine($"            Value: {lineFieldValue.ValueData?.Text}");

                                        if (lineFieldName == "Amount")
                                        {
                                            obj.Amount = lineFieldValue.ValueData?.Text;
                                        }
                                        if (lineFieldName == "Description")
                                        {
                                            obj.Description = lineFieldValue.ValueData?.Text;
                                        }
                                        if (lineFieldName == "Quantity")
                                        {
                                            obj.Quantity = lineFieldValue.ValueData?.Text;
                                        }
                                        if (lineFieldName == "UnitPrice")
                                        {
                                            obj.UnitPrice = lineFieldValue.ValueData?.Text;
                                        }
                                        if (lineFieldName == "Unit")
                                        {
                                            obj.Unit = lineFieldValue.ValueData?.Text;
                                        }
                                        if (lineFieldName == "ProductCode")
                                        {
                                            obj.ProductCode = lineFieldValue.ValueData?.Text;
                                        }

                                    }

                                    if (obj != null)
                                    {
                                        // Item newList = obj;
                                        itemsList.Append(obj);
                                        items = items.Union(new[] { obj });
                                        //items.Append(newList);
                                    }













                                    outObj.Items = outObj.Items.Append(obj).ToList();
                                    // List<Item> latestList = items.Append(obj).ToList();
                                   // List<Item> latestList = new List<Item>

                                    //latestList.Concat(items);
                                    inc++;
                                }
                                // outObj.Items = outObj.items;
                                // List<Item> newList = items.Append(obj).ToList();
                                //  outObj.Items = outObj.Items.Concat(newList);
                                // outObj.Items.Add(obj);
                                invoiceObject.Item = outObj.Items.ToList(); 

                                //invoiceObject.Item = outObj;

                            }
                            // foreach(var a in items)
                            // {
                            //invoiceObject.Item = outObj;
                            //outObj.Items = newList;
                            // outObj.Items = outObj.Items.Concat(newList);
                            //  }
                            //  outObj.Items = outObj.Items.Concat(items);-->delete


                            // invoiceObject.Item = outObj;


                        }


                    }

                    }


                    catch (System.Exception ex)
                    {
                    throw new HttpResponseException(HttpStatusCode.NotFound);
                    }
                    return invoiceObject;

                    }
                    }


                    /* [Serializable]  public class Item
                    {
                    //public string Name { get; set; }
                    //public string Version { get; set; }

                    [Column(TypeName = "VARCHAR")]
                    [StringLength(50)]
                    [Display(Name = "Amount")]
                    public string Amount { get; set; }

                    [Column(TypeName = "VARCHAR")]
                    [StringLength(50)]
                    [Display(Name = "Description")]
                    public string Description { get; set; }

                    [Column(TypeName = "VARCHAR")]
                    [StringLength(50)]
                    [Display(Name = "Quantity")]
                    public string Quantity { get; set; }

                    [Column(TypeName = "string")]
                    [StringLength(50)]
                    [Display(Name = "UnitPrice")]
                    public string UnitPrice { get; set; }

                    [Column(TypeName = "string")]
                    [StringLength(50)]
                    [Display(Name = "ProductCode")]
                    public string ProductCode { get; set; }

                    [Column(TypeName = "string")]
                    [StringLength(50)]
                    [Display(Name = "Unit")]
                    public string Unit { get; set; }

                    [Column(TypeName = "string")]
                    [StringLength(50)]
                    [Display(Name = "Date")]
                    public string Date { get; set; }

                    [Column(TypeName = "string")]
                    [StringLength(50)]
                    [Display(Name = "Tax")]
                    public string Tax { get; set; }
                    }
                    [Serializable] public  class OutputItem
                    {
                    // public List<Item> Items { get; set; }
                    public IEnumerable<Item> Items { get; set; }
                    }

                    }*/





/*
                    using System;
                    using System.IO;
                    using System.Threading.Tasks;
                    using Microsoft.AspNetCore.Mvc;
                    using Microsoft.Azure.WebJobs;
                    using Microsoft.Azure.WebJobs.Extensions.Http;
                    using Microsoft.AspNetCore.Http;
                    using Microsoft.Extensions.Logging;
                    using Newtonsoft.Json;
                    using Azure.AI.FormRecognizer;
                    using Azure.AI.FormRecognizer.Models;
                    using Azure;
                    using System.Linq;
                    using Microsoft.Extensions.Configuration;
                    using Microsoft.AspNetCore.Hosting;
                    using System.Configuration;
                    using System.Net.Http.Headers;
                    using System.Text.Json;
                    using System.Net.Http;
                    using Newtonsoft.Json.Linq;
                    using System.Web.Http;
                    using ServiceStack;
                    using System.Net;
                    using System.Collections;
                    using System.ComponentModel.DataAnnotations.Schema;
                    using System.ComponentModel.DataAnnotations;
                    using System.Collections.Generic;
                    using System.Dynamic;

namespace JSONConverter
        {
            public class convertToPdf
            {

                private readonly IConfiguration _config;


                public convertToPdf(IConfiguration config)
                {
                    _config = config;

                }

                [FunctionName("convertToPdf")]
                public async Task<dynamic> Run(
                      [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] HttpRequest req,
                    ILogger log)
                {
                    var formdata = await req.ReadFormAsync();
                    var file = req.Form.Files[0];
                    Task<dynamic> invoiceData = await parsePdf(file);
                    string jsonString = System.Text.Json.JsonSerializer.Serialize(invoiceData);
                    dynamic json = JsonConvert.DeserializeObject(jsonString);
                    return json;

                }

                public async Task<dynamic> parsePdf(IFormFile file)
                {
                    dynamic eResult = new ExpandoObject();
                    try
                    {
                        JSONConverter.Config config = new JSONConverter.Config();
                        string endPoint = config.getValue("endPoint");
                        string apiKey = config.getValue("apiKey");
                        var credential = new AzureKeyCredential(apiKey);
                        var client = new FormRecognizerClient(new Uri(endPoint), credential);
                        Stream stream = file.OpenReadStream();
                        var options = new RecognizeInvoicesOptions() { Locale = "en-US" };
                        RecognizeInvoicesOperation operation = await client.StartRecognizeInvoicesAsync(stream, options);
                        Response<RecognizedFormCollection> operationResponse = await operation.WaitForCompletionAsync();
                        RecognizedFormCollection invoices = operationResponse.Value;
                        RecognizedForm invoice = invoices.Single();

                        foreach (var Item in operation.Value)
                        {


                            //foreach (FormField field in invoice.Fields.Values)
                            //{
                            //eResult.invoices = invoices.Select(i => new { FormType = i.FormType, pagesCount = i.PageRange.LastPageNumber, fields = i.Fields.Select(f => new { Name = f.Key, Label = f.Value.LabelData.Text, Value = getValue(f.Value) }) });
                            // Console.WriteLine($"Field {field.Name}: ");
                            // Console.WriteLine($"    Value: {field.ValueData?.Text}");
                            //  eResult.invoices = invoices.Select(i => new { FormType = i.FormType, pagesCount = i.PageRange.LastPageNumber, fields = i.Fields.Select(f => new { Name = f.Key, Label = f.Value.LabelData.Text, Value = Item.Fields.Select(f => new {Key = f.Key,Value=f.Value })
                            eResult.invoices = invoices.Select(i => new { FormType = i.FormType, pagesCount = i.PageRange.LastPageNumber, fields = i.Fields.Select(f => new { Name = f.Key, Label = f.Value.LabelData.Text, Value = GetValue(f.Value) }) });
                            // Console.WriteLine($"Field {field.Name}: ");

                            //   }) });
                            //}
                        }
                        var dInvoices = eResult as IDictionary<string, Object>;
                        return eResult;
                        // return dInvoices;
                    }


                    catch (System.Exception ex)
                    {
                        throw new HttpResponseException(HttpStatusCode.NotFound);
                    }
                    return eResult;

                }

                protected dynamic GetValue(FormField f)
                {
                    var valType = f.Value.ValueType;

                    if (valType == FieldValueType.List)
                    {
                        var items = new List<dynamic>();
                        foreach (var item in f.Value.AsList())
                        {
                            items.Add(GetValue(item));
                        }
                        return items;
                    }
                    if (valType == FieldValueType.Dictionary)
                    {
                        dynamic item = new ExpandoObject();
                        var dic = item as Dictionary<string, object>;
                        foreach (var dItem in f.Value.AsDictionary())
                        {
                            dic.Add(dItem.Key, GetValue(dItem.Value));
                        }
                        return item;
                    }
                    else
                        return f.ValueData.Text;
                }
            }




        }




    }
}
*/