﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace JSONConverter
{
    public  class Config
    {
        
        private readonly IConfiguration _config;
        


        
     /*  public string getKey(string name)
        {
            switch (name)
            {
                case "apiKey": string apiKey = "4f0615c2fc5e4c81bfa619fdae89a561";
                             return apiKey;
                         break;
                case "endPoint":
                   string endpoint = "https://skywalk.cognitiveservices.azure.com/";
                    return endpoint;
                    break;
                default:return null;
                    break;
           }
        }*/
        public  String getValue( String keyString )
        {
            return Environment.GetEnvironmentVariable(keyString);
        }
       //
       //     var key= Environment.GetEnvironmentVariable("apiKey");
       //     var a = System.Environment.GetEnvironmentVariable("apiKey", EnvironmentVariableTarget.Process); 
       //    var b =  System.Environment.GetEnvironmentVariable("apiKey", EnvironmentVariableTarget.Process); 
       //     var c = Environment.GetEnvironmentVariable("apiKey",
       //     EnvironmentVariableTarget.Process); ;
       //     var d = System.Environment.GetEnvironmentVariable("apiKey");
       //     var e = config.GetValue<string>("apiKey");
            
        //    var g = new ConfigurationBuilder()
       
       // This gives you access to your application settings 
       // in your local development environment
      // .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
       // This is what actually gets you the 
       // application settings in Azure
     //  .AddEnvironmentVariables()
     //  .Build();

    /*   //     string appsettingvalue = config["apiKey"];
            // var f =  config.GetAppSettings("apiKey");
            var abcd = System.Configuration.ConfigurationManager.AppSettings["endPoint"];
            //return System.Configuration.ConfigurationManager.AppSettings[keyString];
            //return ConfigurationManager.AppSettings[keyString];
            // var f = System.getenv("apiKey");
            return config[keyString];
        }*/
        // return Environment.GetEnvironmentVariable("key");
        // if(returnValue.isEmpty())
        // throw new InvalidConfigException("Please set config value for "+key);    
        // return returnValue; 
        /// }

    }
}
